import os, json, sqlite3, hashlib, time, uuid, logging, re, math
from concurrent.futures import ThreadPoolExecutor
from flask import Flask, request, jsonify, render_template_string, g
from safe import scan_safe
from formats import kind
logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s'); log = logging.getLogger('gap')
app = Flask(__name__); app.config["MAX_CONTENT_LENGTH"] = 20 * 1024 * 1024
DB = os.environ.get("GAP_DB", "gap.db")
MET = dict(scans=0, cache_hits=0, errors=0, malicious=0, suspicious=0, clean=0, scan_seconds=0.0)
SCHEMA = """CREATE TABLE IF NOT EXISTS documents(sha256 TEXT PRIMARY KEY, filename TEXT, doc_type TEXT, uploaded_at REAL, risk_score INT, verdict TEXT, result TEXT);
CREATE TABLE IF NOT EXISTS findings(id INTEGER PRIMARY KEY, sha256 TEXT, page INT, technique TEXT, hidden_text TEXT, severity TEXT);
CREATE TABLE IF NOT EXISTS feedback(id INTEGER PRIMARY KEY, sha256 TEXT, label TEXT, tenant TEXT, ts REAL);
CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY, ts REAL, tenant TEXT, ip TEXT, action TEXT, sha256 TEXT, verdict TEXT);"""
def connect():
    c = sqlite3.connect(DB, timeout=30); c.row_factory = sqlite3.Row; c.executescript(SCHEMA); return c
def db():
    if "db" not in g: g.db = connect()
    return g.db
@app.teardown_appcontext
def close(_):
    d = g.pop("db", None)
    if d: d.close()
API_KEY = os.environ.get("GAP_API_KEY"); KEYS = json.loads(os.environ.get("GAP_KEYS", "{}")); HITS = {}
# GAP_KEYS = {"key1": {"tenant": "acme", "suspicious": 25, "malicious": 60}}  -> per-tenant API keys + thresholds
def policy(cfg, r):
    r = dict(r); s = r["risk_score"]; r["verdict"] = "MALICIOUS" if s >= cfg.get("malicious", 70) else "SUSPICIOUS" if s >= cfg.get("suspicious", 30) else "CLEAN"; return r
@app.before_request
def guard():
    g.cfg = {"tenant": "default"}
    if not request.path.startswith("/api/"): return
    k = request.headers.get("X-API-Key")
    if KEYS:
        if k not in KEYS: return jsonify(error="unauthorized"), 401
        g.cfg = KEYS[k]
    elif API_KEY and k != API_KEY: return jsonify(error="unauthorized"), 401
    now = time.time(); h = [t for t in HITS.get(request.remote_addr, []) if now - t < 60]
    if len(h) >= int(os.environ.get("RATE_PER_MIN", 20)): return jsonify(error="rate limit"), 429
    HITS[request.remote_addr] = h + [now]
def run(data, fname, dtype, d, tenant="default", ip="", deep=False):
    sha = hashlib.sha256(data).hexdigest()
    row = None if deep else d.execute("SELECT result FROM documents WHERE sha256=?", (sha,)).fetchone()
    if row:
        MET["cache_hits"] += 1; r = json.loads(row["result"]); r["cached"] = True
    else:
        t0 = time.time(); r = scan_safe(data, timeout=int(os.environ.get("SCAN_TIMEOUT", 120)), deep=deep) if kind(data) == "pdf" else scan_safe(data)
        dt = time.time() - t0; MET["scans"] += 1; MET["scan_seconds"] += dt; MET[r["verdict"].lower()] += 1
        log.info("scan sha=%s verdict=%s score=%s findings=%d %.1fs", sha[:12], r["verdict"], r["risk_score"], len(r["findings"]), dt)
        d.execute("INSERT OR REPLACE INTO documents VALUES(?,?,?,?,?,?,?)", (sha, re.sub(r"[^\w.\- ]", "_", fname)[:200], dtype, time.time(), r["risk_score"], r["verdict"], json.dumps(r)))
        d.execute("DELETE FROM findings WHERE sha256=?", (sha,))
        d.executemany("INSERT INTO findings(sha256,page,technique,hidden_text,severity) VALUES(?,?,?,?,?)", [(sha, f["page"], f["technique"], f["text"][:500], f["severity"]) for f in r["findings"]])
    d.execute("INSERT INTO audit(ts,tenant,ip,action,sha256,verdict) VALUES(?,?,?,?,?,?)", (time.time(), tenant, ip, "scan", sha, r["verdict"])); d.commit(); return r
def _upload():
    f = request.files.get("file"); data = f.read() if f else b""
    return (data, f.filename if f else "") if kind(data) else (None, None)
@app.post("/api/scan")
def api_scan():
    data, fn = _upload()
    if data is None: return jsonify(error="supported file nahi (PDF/DOCX/HTML)"), 400
    try: return jsonify(policy(g.cfg, run(data, fn or "upload", request.form.get("doc_type", "resume"), db(), g.cfg["tenant"], request.remote_addr, request.form.get("deep") == "1")))
    except TimeoutError as e: MET["errors"] += 1; return jsonify(error=str(e)), 504
    except Exception as e: MET["errors"] += 1; log.warning("scan fail: %s", e); return jsonify(error=f"scan fail: {e}"), 422
EX = ThreadPoolExecutor(int(os.environ.get("WORKERS", 2))); JOBS = {}
def _work(jid, data, fn, dt, tenant, ip, deep, cfg):
    d = connect()
    try: JOBS[jid] = dict(status="done", result=policy(cfg, run(data, fn, dt, d, tenant, ip, deep)))
    except Exception as e: JOBS[jid] = dict(status="error", error=str(e))
    finally: d.close()
@app.post("/api/jobs")
def job_submit():
    data, fn = _upload()
    if data is None: return jsonify(error="supported file nahi"), 400
    jid = uuid.uuid4().hex; JOBS[jid] = dict(status="queued")
    EX.submit(_work, jid, data, fn or "upload", request.form.get("doc_type", "resume"), g.cfg["tenant"], request.remote_addr, request.form.get("deep") == "1", dict(g.cfg))
    return jsonify(job_id=jid, status="queued"), 202
@app.get("/api/jobs/<jid>")
def job_get(jid): return (jsonify(JOBS[jid]) if jid in JOBS else (jsonify(error="unknown job"), 404))
@app.post("/api/sanitize")
def sanitize():
    data, fn = _upload()
    if data is None: return jsonify(error="supported file nahi"), 400
    r = policy(g.cfg, run(data, fn or "upload", "other", db(), g.cfg["tenant"], request.remote_addr))
    return r["clean_text"], 200, {"Content-Type": "text/plain; charset=utf-8", "X-Risk-Score": str(r["risk_score"]), "X-Verdict": r["verdict"]}
@app.post("/api/feedback")
def feedback():
    j = request.get_json(silent=True) or {}
    if j.get("label") not in ("allow", "deny") or not j.get("sha256"): return jsonify(error="need sha256 + label allow|deny"), 400
    db().execute("INSERT INTO feedback(sha256,label,tenant,ts) VALUES(?,?,?,?)", (j["sha256"], j["label"], g.cfg["tenant"], time.time())); db().commit(); return jsonify(ok=True)
@app.get("/api/drift")
def drift():
    s = [r[0] for r in db().execute("SELECT risk_score FROM documents ORDER BY uploaded_at").fetchall()]
    if len(s) < 40: return jsonify(status="insufficient_data", n=len(s))
    ref, cur = s[:-30], s[-30:]; bins = [0, 10, 30, 70, 101]
    frac = lambda x: [max(sum(a <= v < b for v in x) / len(x), 1e-4) for a, b in zip(bins, bins[1:])]
    psi = sum((c - r) * math.log(c / r) for c, r in zip(frac(cur), frac(ref)))
    return jsonify(psi=round(psi, 3), level="stable" if psi < .1 else "moderate" if psi < .25 else "DRIFT", n_ref=len(ref), n_cur=len(cur))
@app.get("/api/stats")
def stats():
    rows = db().execute("SELECT technique, COUNT(*) n FROM findings GROUP BY technique ORDER BY n DESC").fetchall()
    docs = db().execute("SELECT filename, risk_score, verdict, uploaded_at FROM documents ORDER BY uploaded_at DESC LIMIT 50").fetchall()
    return jsonify(techniques=[dict(r) for r in rows], recent=[dict(r) for r in docs])
@app.get("/api/audit")
def audit(): return jsonify([dict(r) for r in db().execute("SELECT * FROM audit WHERE tenant=? ORDER BY ts DESC LIMIT 100", (g.cfg["tenant"],)).fetchall()])
@app.after_request
def sec(r):
    r.headers.update({"X-Content-Type-Options": "nosniff", "X-Frame-Options": "DENY", "Referrer-Policy": "no-referrer",
        "Content-Security-Policy": "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'"}); return r
@app.get("/metrics")
def metrics(): return "".join(f"gap_{k} {v}\n" for k, v in MET.items()), 200, {"Content-Type": "text/plain"}
@app.get("/health")
def health(): return jsonify(ok=True)
PAGE = """<!doctype html><meta name=viewport content="width=device-width,initial-scale=1"><title>Gap Scanner</title>
<style>body{font:15px system-ui;max-width:760px;margin:auto;padding:14px;background:#f6f7f9}h1{font-size:20px}.c{background:#fff;border-radius:10px;padding:12px;margin:10px 0;box-shadow:0 1px 3px #0002}
.s{font-size:42px;font-weight:700}.MALICIOUS{color:#c0392b}.SUSPICIOUS{color:#d68910}.CLEAN{color:#1e8449}button,select{padding:10px;font-size:15px}
.f{border-left:4px solid #999;padding-left:8px;margin:8px 0}.high{border-color:#c0392b}.medium{border-color:#d68910}img{max-width:100%;border:1px solid #ccc}pre{white-space:pre-wrap;background:#eef;padding:8px;border-radius:6px}</style>
<h1>🔍 Render-vs-Read Gap Scanner</h1><div class=c><input type=file id=f accept=.pdf,.docx,.html,.htm> <label><input type=checkbox id=dp>deep(image)</label> <select id=t><option>resume<option>invoice<option>other</select> <button onclick=go()>Scan</button> <span id=m></span></div><div id=o></div>
<script>async function go(){const f=document.getElementById('f').files[0];if(!f)return;m.textContent='Scanning (OCR chalta hai, 10-60s)...';o.innerHTML='';
const fd=new FormData();fd.append('file',f);fd.append('doc_type',t.value);if(dp.checked)fd.append('deep','1');const r=await fetch('/api/scan',{method:'POST',body:fd});const j=await r.json();m.textContent='';
if(j.error){o.innerHTML='<div class=c>❌ '+j.error+'</div>';return}
const e=s=>String(s).replace(/[&<>]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]));
let h=`<div class=c><div class="s ${j.verdict}">${j.risk_score}/100 ${j.verdict}</div><small>${j.pages} pages · sha256 ${j.sha256.slice(0,12)}${j.cached?' · cached':''}</small><pre>${e(JSON.stringify(j.features,null,1))}</pre></div>`;
if(j.explain&&j.explain.length)h+='<div class=c><b>Why this score</b>'+j.explain.map(x=>`<div>${x.feature}=${x.value} → ${x.contribution_pct>0?'+':''}${x.contribution_pct}%</div>`).join('')+'</div>';
h+='<div class=c><b>Findings ('+j.findings.length+')</b>'+j.findings.map(x=>`<div class="f ${x.severity}"><b>${x.technique}</b> p${x.page||'-'} · inj ${(x.injection*100|0)}%<br>${e(x.text.slice(0,300))}</div>`).join('')+'</div>';
h+=j.previews.map(p=>`<div class=c>Page ${p.page} (red = hidden)<br><img src="${p.image}"></div>`).join('');
h+=`<div class=c><b>Clean text (RAG-safe)</b><pre>${e(j.clean_text)}</pre></div>`;o.innerHTML=h}</script>"""
@app.get("/")
def index(): return render_template_string(PAGE)
if __name__ == "__main__": app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)))
