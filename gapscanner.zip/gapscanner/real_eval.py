"""Validate on YOUR real PDFs: python real_eval.py <folder_of_clean_pdfs> [--n 3]
Measures false-positive rate on the untouched PDFs, then injects each attack technique INTO them (overlay on the real page) and measures recall."""
import sys, os, io, glob, random, csv, collections
from reportlab.pdfgen import canvas
from pypdf import PdfReader, PdfWriter
import dataset
from scanner import scan
folder = sys.argv[1]; n = int(sys.argv[sys.argv.index("--n") + 1]) if "--n" in sys.argv else 3
files = sorted(glob.glob(os.path.join(folder, "**", "*.pdf"), recursive=True))
def inject(b, tech):
    r = PdfReader(io.BytesIO(b)); w = PdfWriter(); w.append(r); pg = w.pages[0]; W, H = float(pg.mediabox.width), float(pg.mediabox.height)
    o = io.BytesIO(); c = canvas.Canvas(o, pagesize=(W, H)); dataset.attack(c, tech, random.choice(dataset.INJ)); c.save()
    if tech != "metadata": pg.merge_page(PdfReader(io.BytesIO(o.getvalue())).pages[0])
    if tech == "metadata": w.add_metadata({"/Subject": random.choice(dataset.INJ)})
    out = io.BytesIO(); w.write(out); return out.getvalue()
fp, rows, rec = 0, [], collections.defaultdict(list)
for f in files:
    b = open(f, "rb").read(); r = scan(b, highlights=False); fp += r["verdict"] == "MALICIOUS"; rows.append((f, "clean", r["verdict"], r["risk_score"]))
    print(f"CLEAN {r['verdict']:10} {r['risk_score']:3} {os.path.basename(f)}", flush=True)
for f in files[:n]:
    b = open(f, "rb").read()
    for t in dataset.TECH:
        try: r = scan(inject(b, t), highlights=False)
        except Exception as e: print("inject fail", t, e); continue
        rec[t].append(r["verdict"] != "CLEAN"); rows.append((f, t, r["verdict"], r["risk_score"]))
print(f"\nFALSE POSITIVE (MALICIOUS on clean): {fp}/{len(files)} = {fp/max(len(files),1):.3f}")
for t, v in rec.items(): print(f"recall {t:16} {sum(v)}/{len(v)}")
csv.writer(open("real_eval.csv", "w", newline="")).writerows([("file", "kind", "verdict", "score")] + rows)
