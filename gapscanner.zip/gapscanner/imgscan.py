"""Image-embedded hidden text: OCR a contrast-amplified copy; words seen only there = near-invisible text (human can't see, OCR/VLM can)."""
import re, pytesseract
from PIL import ImageOps, ImageFilter
def hidden_in_image(img, ocr, page, sc, lo=200, hi=253, min_words=3):
    enh = ImageOps.grayscale(img).point(lambda p: 0 if lo <= p <= hi else 255).filter(ImageFilter.MedianFilter(3))
    od = pytesseract.image_to_data(enh, output_type=pytesseract.Output.DICT); seen = {o[4] for o in ocr}; lines = {}
    for k, t in enumerate(od["text"]):
        n = re.sub(r"[^a-z]", "", t.lower())
        if len(n) < 3 or float(od["conf"][k]) < 70 or n in seen: continue
        lines.setdefault((od["block_num"][k], od["par_num"][k], od["line_num"][k]), []).append((od["left"][k], od["top"][k], od["left"][k] + od["width"][k], od["top"][k] + od["height"][k], t))
    out = []
    for ws in lines.values():
        if len(ws) < min_words: continue
        out.append(dict(page=page, technique="image_hidden_text", text=" ".join(w[4] for w in ws),
                        bbox=[min(w[0] for w in ws) / sc, min(w[1] for w in ws) / sc, max(w[2] for w in ws) / sc, max(w[3] for w in ws) / sc]))
    return out
