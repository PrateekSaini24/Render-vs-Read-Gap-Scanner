"""Render-vs-Read Gap Scanner core. Text layer (pdfplumber) vs rendered+OCR (pdf2image+tesseract) + structure (pikepdf)."""
import re, io, os, math, base64, difflib, hashlib, pickle
import pdfplumber, pikepdf, pytesseract
from pdf2image import convert_from_bytes
from PIL import ImageDraw

DPI, MAX_PAGES = 200, 30
for _p in (os.environ.get("TESSERACT_CMD"), r"C:\Program Files\Tesseract-OCR\tesseract.exe"):   # Windows: auto-detect default install
    if _p and os.path.exists(_p): pytesseract.pytesseract.tesseract_cmd = _p; break
POPPLER = os.environ.get("POPPLER_PATH") or None   # Windows: folder containing pdftoppm.exe
CONF = dict(zip("аеорсухіјѕһАВЕКМНОРСТХαονικρτυΑΒΕΟΡΤΖΙΚΜΝΧℓ", "aeopcyxijshABEKMHOPCTXaovikrtuABEOPTZIKMNXl"))
def demix(t): return "".join(CONF.get(c, c) for c in t)
def mixed_script(w):
    L = [c for c in w if c.isalpha()]
    return any(c in CONF for c in L) and any(c.isascii() for c in L)
def sim(a, b):
    """TF-IDF cosine between hidden and visible text (low = off-topic hidden content)."""
    if not a.strip() or not b.strip(): return 1.0
    try:
        from sklearn.feature_extraction.text import TfidfVectorizer
        M = TfidfVectorizer().fit([a, b]).transform([a, b]); return float(M[0].multiply(M[1]).sum())
    except Exception: return 1.0
SOFT = ("homoglyph", "zero_width_or_tag_chars")
ZW = re.compile("[\u200b-\u200f\u2060\ufeff\u00ad]")
INJ = [  # (regex, weight)
 (r"ignore\s+(all\s+|any\s+)?(previous|prior|above|earlier)\s+(instructions?|prompts?)", 1.6),
 (r"disregard\s+(all\s+|the\s+)?(previous|prior|above|instructions?)", 1.5),
 (r"(system|developer)\s+(prompt|message|instruction)", 1.2),
 (r"you\s+are\s+(now\s+|an?\s+)", 0.6),
 (r"(rank|rate|score|select|shortlist)\s+(this|the)\s+(candidate|resume|applicant|document)", 1.3),
 (r"top\s+(rank|candidate|choice|priority)", 1.0),
 (r"(strongly\s+)?(recommend|hire)\s+(this|the)\s+(candidate|applicant)", 1.2),
 (r"do\s+not\s+(mention|reveal|tell|disclose)", 1.0),
 (r"\b(override|jailbreak|bypass)\b", 0.8),
 (r"\b(llm|ai|language model|assistant|screener|chatbot)\b", 0.5),
 (r"\b(10\s*/\s*10|perfect\s+(score|match)|highest\s+score)\b", 0.8),
 (r"(approve|pay)\s+(this\s+)?(invoice|payment)|change\s+(the\s+)?(bank|account)", 1.0),
]
INJ = [(re.compile(p, re.I), w) for p, w in INJ]

_CLF = None
def _transformer(text):
    """Optional DeBERTa-style classifier: INJ_MODEL=protectai/deberta-v3-base-prompt-injection-v2 (needs transformers+torch)."""
    global _CLF
    if _CLF is None:
        from transformers import pipeline
        _CLF = pipeline("text-classification", model=os.environ["INJ_MODEL"], truncation=True, max_length=512)
    r = _CLF(text[:2000])[0]
    return r["score"] if r["label"].upper() in ("INJECTION", "LABEL_1", "UNSAFE") else 1 - r["score"]

def injection_score(text):
    text = demix(text); s, hits = 0.0, []
    for rx, w in INJ:
        if rx.search(text): s += w; hits.append(rx.pattern[:40])
    rx_score = 1 - math.exp(-s)
    if os.environ.get("INJ_MODEL") and len(text) > 15:
        try: return max(rx_score, _transformer(text)), hits + ["transformer"]
        except Exception: pass
    try:
        if len(text.split()) < 4: return rx_score, hits  # short strings: classifier unreliable, regex only
        from text_clf import prob
        pc = prob(text)
        if pc > rx_score: hits = hits + [f"text_clf:{pc:.2f}"]
        rx_score = max(rx_score, pc)
    except Exception: pass
    return rx_score, hits

def decode_tags(t):  # Unicode tag chars (U+E0000..E007F) = invisible ASCII smuggling
    return "".join(chr(ord(c) - 0xE0000) for c in t if 0xE0020 <= ord(c) <= 0xE007E)

def _rgb(c):
    if c is None: return (0, 0, 0)
    if isinstance(c, (int, float)): c = (c,)
    try: c = [float(x) for x in c]
    except Exception: return (0, 0, 0)
    if len(c) == 1: return (c[0],) * 3
    if len(c) == 3: return tuple(c)
    if len(c) == 4: k = c[3]; return tuple((1 - v) * (1 - k) for v in c[:3])
    return (0, 0, 0)

def _lum(rgb):
    f = lambda v: v / 12.92 if v <= .03928 else ((v + .055) / 1.055) ** 2.4
    r, g, b = [f(min(max(v, 0), 1)) for v in rgb]
    return .2126 * r + .7152 * g + .0722 * b

def contrast(a, b):
    la, lb = _lum(a), _lum(b)
    return (max(la, lb) + .05) / (min(la, lb) + .05)

def norm(s): return re.sub(r"[^a-z0-9]", "", s.lower())

FEATS = ["hidden_token_ratio", "hidden_chars", "n_techniques", "injection_score", "struct_injection", "min_contrast", "min_font", "n_high", "homoglyph_count", "doc_hidden_injection", "hidden_visible_sim"]
BASE = dict(min_contrast=21.0, min_font=72.0, hidden_visible_sim=1.0)
_M = {}
def _model():
    p = os.path.join(os.path.dirname(os.path.abspath(__file__)), "model.pkl")
    if "m" not in _M: _M["m"] = pickle.load(open(p, "rb")) if os.path.exists(p) else None
    return _M["m"]

def structural(pdf_bytes):
    """Checks E: metadata, annotations, embedded files, JS, OCG-off, render mode 3."""
    out, texts, tr3 = [], [], set()
    pdf = pikepdf.open(io.BytesIO(pdf_bytes))
    for k, v in (pdf.docinfo or {}).items():
        v = str(v)
        if len(v) > 0: texts.append(("metadata:" + str(k), v))
    root = pdf.Root
    names = root.get("/Names", {})
    if "/EmbeddedFiles" in names: out.append(("embedded_file", "PDF me embedded file hai"))
    if "/JavaScript" in names or "/OpenAction" in root: out.append(("javascript", "JavaScript/OpenAction present"))
    af = root.get("/AcroForm")
    if af is not None and "/XFA" in af: out.append(("xfa_form", "XFA form present (dynamic content, scanner ke bahar ka text ho sakta hai)"))
    eofs = [m.end() for m in re.finditer(rb"%%EOF", pdf_bytes)]
    if len(eofs) > 1:
        out.append(("incremental_update", f"{len(eofs)} revisions: purana/deleted content recoverable ho sakta hai"))
        try:
            def words(b):
                with pdfplumber.open(io.BytesIO(b)) as d: return {w["text"] for p in d.pages[:5] for w in p.extract_words()}
            new = words(pdf_bytes); old = set()
            for e in eofs[:-1]: old |= words(pdf_bytes[:e])
            gone = sorted(old - new)
            if len(gone) >= 3: texts.append(("revision", " ".join(gone)[:600]))
        except Exception: pass
    ocp = root.get("/OCProperties")
    if ocp is not None:
        off = ocp.get("/D", {}).get("/OFF", [])
        if len(off): out.append(("hidden_layer", f"{len(off)} optional content layer(s) default OFF"))
    for i, page in enumerate(pdf.pages[:MAX_PAGES]):
        for a in page.get("/Annots", []) or []:
            for key in ("/Contents", "/V", "/TU"):
                if key in a and len(str(a[key])) > 0:
                    texts.append((f"annotation(p{i+1})", str(a[key])))
        try:
            for ins in pikepdf.parse_content_stream(page):
                if str(ins.operator) == "Tr" and int(ins.operands[0]) == 3: tr3.add(i)
        except Exception: pass
    for p in sorted(tr3): out.append(("render_mode_3", f"page {p+1}: invisible text render mode (3 Tr)"))
    return out, texts

def _rotated_words(page):
    out, cur, prev = [], [], None
    def flush():
        if cur:
            out.append(dict(text="".join(c["text"] for c in cur), x0=min(c["x0"] for c in cur), x1=max(c["x1"] for c in cur), top=min(c["top"] for c in cur),
                            bottom=max(c["bottom"] for c in cur), size=cur[0]["size"], non_stroking_color=cur[0].get("non_stroking_color"), upright=0)); cur.clear()
    for c in page.chars:
        if c.get("upright", 1): flush(); prev = None; continue
        if c["text"].isspace(): flush(); prev = None; continue
        if prev is not None and math.hypot(c["x0"] - prev["x0"], c["top"] - prev["top"]) > 2.5 * max(c["size"], 1): flush()
        cur.append(c); prev = c
    flush(); return out

def _guard(pdf_bytes):
    """Reject decompression/pixel bombs and huge pages before rendering."""
    pdf = pikepdf.open(io.BytesIO(pdf_bytes))
    for p in list(pdf.pages)[:MAX_PAGES]:
        x0, y0, x1, y1 = [float(v) for v in p.mediabox]
        if (x1 - x0) * (y1 - y0) > (60 * 72) ** 2: raise ValueError("page size bahut bada hai (>60 inch)")

def scan(pdf_bytes, highlights=True, deep=False):
    _guard(pdf_bytes)
    sha = hashlib.sha256(pdf_bytes).hexdigest()
    struct_flags, struct_texts = structural(pdf_bytes)
    images = convert_from_bytes(pdf_bytes, dpi=DPI, last_page=MAX_PAGES, poppler_path=POPPLER)
    sc = DPI / 72
    findings, visible_pages, total_words, hidden_words = [], [], 0, 0
    min_c, min_sz, homog = 21.0, 72.0, 0
    tags_text = ""
    with pdfplumber.open(io.BytesIO(pdf_bytes)) as pdf:
        for pi, page in enumerate(pdf.pages[:MAX_PAGES]):
            img = images[pi]; gray = img.convert("L")
            W, H = page.width, page.height
            od = pytesseract.image_to_data(img, output_type=pytesseract.Output.DICT)
            ocr = [(od["left"][k], od["top"][k], od["left"][k] + od["width"][k], od["top"][k] + od["height"][k], norm(od["text"][k]))
                   for k in range(len(od["text"])) if od["text"][k].strip() and float(od["conf"][k]) > 20]
            words = page.extract_words(extra_attrs=["size", "non_stroking_color"], keep_blank_chars=False, use_text_flow=True)
            words = [w for w in words if w.get("upright", 1)] + _rotated_words(page)   # rotated text: pdfplumber splits per-letter, regroup ourselves
            vis_words, runs = [], []
            for w in words:
                raw = w["text"]
                tags_text += decode_tags(raw)
                clean = ZW.sub("", re.sub("[\U000E0000-\U000E007F]", "", raw))
                if raw != clean and len(raw) - len(clean) >= 1:
                    runs.append(dict(page=pi + 1, technique="zero_width_or_tag_chars", bbox=[w["x0"], w["top"], w["x1"], w["bottom"]], text=decode_tags(raw) or "[zero-width chars]"))
                n = norm(clean)
                if not n: continue
                if mixed_script(clean): homog += 1; runs.append(dict(page=pi + 1, technique="homoglyph", bbox=[w["x0"], w["top"], w["x1"], w["bottom"]], text=clean))
                total_words += 1
                x0, y0, x1, y1 = w["x0"] * sc, w["top"] * sc, w["x1"] * sc, w["bottom"] * sc
                tech = None; c = 21.0
                if w["x1"] < 0 or w["x0"] > W or w["bottom"] < 0 or w["top"] > H:
                    tech = "off_page"
                else:
                    cx0, cy0, cx1, cy1 = [int(max(0, v)) for v in (x0 - 2, y0 - 2, x1 + 2, y1 + 2)]
                    cx1, cy1 = min(cx1, img.width), min(cy1, img.height)
                    bg = 1.0
                    if cx1 > cx0 and cy1 > cy0:
                        px = sorted(gray.crop((cx0, cy0, cx1, cy1)).getdata()); bg = px[len(px) // 2] / 255
                    c = contrast(_rgb(w["non_stroking_color"]), (bg,) * 3)
                    ov = " ".join(o[4] for o in ocr if min(o[2], x1) - max(o[0], x0) > 0 and min(o[3], y1) - max(o[1], y0) > 0)
                    seen = n in ov or difflib.SequenceMatcher(None, n, ov).find_longest_match(0, len(n), 0, len(ov)).size >= max(2, int(.7 * len(n)))
                    if c < 1.5: tech = "low_contrast"
                    elif not seen:
                        tech = "tiny_font" if w["size"] < 2 else ("glyph_or_overlap_mismatch" if ov.strip() else "covered_or_invisible")
                if tech:
                    hidden_words += 1; min_c = min(min_c, c); min_sz = min(min_sz, w['size'])
                    runs.append(dict(page=pi + 1, technique=tech, bbox=[w["x0"], w["top"], w["x1"], w["bottom"]], text=clean))
                else: vis_words.append(clean)
            if not words and ocr:  # scanned / image-only page: OCR text is the only text
                visible_pages.append(" ".join(od["text"][k] for k in range(len(od["text"])) if od["text"][k].strip()))
                findings.append(dict(page=pi + 1, technique="image_only_page", text="Text layer nahi hai; OCR use hua", bbox=None, injection=0, matches=[], severity="low"))
            else: visible_pages.append(" ".join(vis_words))
            if deep:
                import imgscan; runs += imgscan.hidden_in_image(img, ocr, pi + 1, sc)
            # merge consecutive same-technique words into findings
            merged = []
            for r in runs:
                m = merged[-1] if merged else None
                if m and m["page"] == r["page"] and m["technique"] == r["technique"] and (abs(m["bbox"][1] - r["bbox"][1]) < 15 or abs(m["bbox"][0] - r["bbox"][0]) < 15):
                    m["text"] += " " + r["text"]
                    m["bbox"] = [min(m["bbox"][0], r["bbox"][0]), min(m["bbox"][1], r["bbox"][1]), max(m["bbox"][2], r["bbox"][2]), max(m["bbox"][3], r["bbox"][3])]
                else: merged.append(r)
            findings += merged
            if highlights and any(f["page"] == pi + 1 for f in merged):
                d = ImageDraw.Draw(img)
                for f in merged:
                    if f["page"] == pi + 1:
                        b = [v * sc for v in f["bbox"]]; d.rectangle(b, outline="red", width=4)
                img.thumbnail((900, 1200)); buf = io.BytesIO(); img.save(buf, "PNG")
                findings.append(dict(page=pi + 1, technique="_preview", image="data:image/png;base64," + base64.b64encode(buf.getvalue()).decode()))
    previews = [f for f in findings if f["technique"] == "_preview"]
    findings = [f for f in findings if f["technique"] != "_preview"]
    # injection analysis
    for f in findings:
        f["injection"], f["matches"] = injection_score(f["text"])
        f["severity"] = "high" if f["injection"] > .6 else "medium" if f["injection"] > .3 or f["technique"] in ("off_page", "low_contrast") else "low"
    for fl, txt in struct_flags: findings.append(dict(page=0, technique=fl, text=txt, bbox=None, injection=0, matches=[], severity="medium"))
    struct_inj = 0.0
    for src, t in struct_texts:
        s, m = injection_score(t)
        if s > .3: findings.append(dict(page=0, technique="hidden_in_" + src.split(":")[0].split("(")[0], text=t[:300], bbox=None, injection=s, matches=m, severity="high")); struct_inj = max(struct_inj, s)
    if tags_text:
        s, m = injection_score(tags_text); struct_inj = max(struct_inj, s)
    # risk scoring: logistic over interpretable features
    hid_chars = sum(len(f["text"]) for f in findings if f.get("bbox") and f["technique"] not in SOFT)
    doc_hidden = " ".join(f["text"] for f in findings if f.get("bbox") and f["technique"] not in SOFT)
    dinj = injection_score(doc_hidden)[0] if len(doc_hidden.split()) >= 3 else 0.0   # split-across-pages/lines attacks
    inj = max([f["injection"] for f in findings] + [dinj, 0])
    techs = len({f["technique"] for f in findings if f["technique"] != "image_only_page"})
    feats = dict(hidden_token_ratio=round(hidden_words / max(total_words, 1), 4), hidden_chars=hid_chars, n_techniques=techs, injection_score=round(inj, 3), struct_injection=round(struct_inj, 3), min_contrast=round(min_c, 2), min_font=round(min_sz, 1), n_high=sum(f['severity'] == 'high' for f in findings), homoglyph_count=homog, doc_hidden_injection=round(dinj, 3), hidden_visible_sim=round(sim(doc_hidden, " ".join(visible_pages)), 3))
    feats["n_findings"] = len(findings)
    z = -4.0 + 4.5 * inj + 2.5 * min(hid_chars / 150, 1) + 0.8 * min(techs, 4) + 1.5 * struct_inj
    score = round(100 / (1 + math.exp(-z)))
    m = _model()
    if m is not None: score = round(100 * float(m.predict_proba([[feats[k] for k in FEATS]])[0][1]))
    verdict = "MALICIOUS" if score >= 70 else "SUSPICIOUS" if score >= 30 else "CLEAN"
    return dict(sha256=sha, pages=len(visible_pages), risk_score=score, verdict=verdict, features=feats,
                findings=findings, clean_text="\n\n".join(visible_pages), previews=previews, explain=explain(feats))


def explain(feats):
    """Ablation explanation: score drop when a feature is reset to its 'clean' baseline (model-agnostic, SHAP-like)."""
    m = _model()
    if m is None: return []
    v = [feats[k] for k in FEATS]; p0 = float(m.predict_proba([v])[0][1]); out = []
    for i, k in enumerate(FEATS):
        w = list(v); w[i] = BASE.get(k, 0); d = p0 - float(m.predict_proba([w])[0][1])
        if abs(d) > .02: out.append(dict(feature=k, value=feats[k], contribution_pct=round(100 * d, 1)))
    return sorted(out, key=lambda x: -abs(x["contribution_pct"]))[:5]
