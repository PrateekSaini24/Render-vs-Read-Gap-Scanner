"""Active learning: analyst allow/deny feedback (gap.db) + dataset -> retrain model.pkl. python retrain_feedback.py"""
import csv, json, pickle, shutil, sqlite3, os, numpy as np
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.calibration import CalibratedClassifierCV
import scanner
cache = json.load(open("data/features.json")); rows = list(csv.DictReader(open("data/labels.csv")))
X = [[cache[r["path"]][k] for k in scanner.FEATS] for r in rows]; y = [int(r["label"]) for r in rows]; n0 = len(y)
d = sqlite3.connect(os.environ.get("GAP_DB", "gap.db")); d.row_factory = sqlite3.Row
for f in d.execute("SELECT f.label, doc.result FROM feedback f JOIN documents doc ON doc.sha256=f.sha256"):
    ft = json.loads(f["result"])["features"]
    if all(k in ft for k in scanner.FEATS): X.append([ft[k] for k in scanner.FEATS]); y.append(1 if f["label"] == "deny" else 0)
print(f"{len(y)-n0} feedback samples added to {n0}")
if os.path.exists("model.pkl"): shutil.copy("model.pkl", "model.prev.pkl")
pickle.dump(CalibratedClassifierCV(GradientBoostingClassifier(n_estimators=80, max_depth=2, random_state=0), method="sigmoid", cv=3).fit(np.array(X), np.array(y)), open("model.pkl", "wb")); print("model.pkl updated (backup: model.prev.pkl)")
