"""Scan dataset -> features (cached) -> 5-fold CV of calibrated GradientBoosting (Platt) -> OOF metrics w/ bootstrap 95% CI -> model.pkl + report.md."""
import csv, json, os, pickle, time
import numpy as np
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.calibration import CalibratedClassifierCV
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import roc_auc_score, f1_score, precision_score, recall_score, confusion_matrix
import scanner
rows = list(csv.DictReader(open("data/labels.csv"))) + (list(csv.DictReader(open("data/redteam_labels.csv", newline=""), fieldnames=["path", "label", "technique", "kind"])) if os.path.exists("data/redteam_labels.csv") else []); C = "data/features.json"
cache = json.load(open(C)) if os.path.exists(C) else {}; t0 = time.time()
for i, r in enumerate(rows):
    if r["path"] not in cache: cache[r["path"]] = scanner.scan(open(r["path"], "rb").read(), highlights=False)["features"]
    if i % 25 == 0: print(i, "/", len(rows), f"{time.time()-t0:.0f}s", flush=True); json.dump(cache, open(C, "w"))
json.dump(cache, open(C, "w"))
X = np.array([[cache[r["path"]][k] for k in scanner.FEATS] for r in rows]); y = np.array([int(r["label"]) for r in rows]); tech = np.array([r["technique"] for r in rows])
mk = lambda: CalibratedClassifierCV(GradientBoostingClassifier(n_estimators=80, max_depth=2, random_state=0), method="sigmoid", cv=3)
oof = np.zeros(len(y))
for tr, te in StratifiedKFold(5, shuffle=True, random_state=1).split(X, y): oof[te] = mk().fit(X[tr], y[tr]).predict_proba(X[te])[:, 1]
json.dump({r["path"]: float(p) for r, p in zip(rows, oof)}, open("data/oof.json", "w")); pred = oof >= .5; rng = np.random.default_rng(0)
def ci(fn):
    v = []
    for _ in range(1000):
        i = rng.integers(0, len(y), len(y)); v.append(fn(y[i], pred[i]))
    return np.percentile(v, [2.5, 97.5])
fpr = lambda yt, p: (p & (yt == 0)).sum() / max((yt == 0).sum(), 1)
tn, fp, fn, tp = confusion_matrix(y, pred).ravel(); cf, cp = ci(f1_score), ci(fpr)
L = [f"# Evaluation - 5-fold cross-validation, out-of-fold predictions on {len(y)} PDFs", "",
 f"- ROC-AUC {roc_auc_score(y, oof):.3f}", f"- Precision {precision_score(y, pred):.3f}  Recall {recall_score(y, pred):.3f}  F1 {f1_score(y, pred):.3f}  (95% CI F1 {cf[0]:.3f}-{cf[1]:.3f})",
 f"- **False positive rate {fpr(y, pred):.3f}** (95% CI {cp[0]:.3f}-{cp[1]:.3f})", f"- Confusion: TN={tn} FP={fp} FN={fn} TP={tp}", "",
 "| technique | n | flagged |", "|---|---|---|"]
L += [f"| {t} | {(tech == t).sum()} | {pred[tech == t].mean():.2f} |" for t in sorted(set(tech))]
if os.path.exists("textclf_report.json"): L += ["", "Text classifier (unseen phrasings): " + open("textclf_report.json").read()]
open("report.md", "w").write("\n".join(L)); print("\n".join(L))
pickle.dump(mk().fit(X, y), open("model.pkl", "wb")); print("model.pkl saved")
