# Evaluation - 5-fold cross-validation, out-of-fold predictions on 150 PDFs

- ROC-AUC 1.000
- Precision 1.000  Recall 1.000  F1 1.000  (95% CI F1 1.000-1.000)
- **False positive rate 0.000** (95% CI 0.000-0.000)
- Confusion: TN=70 FP=0 FN=0 TP=80

| technique | n | flagged |
|---|---|---|
| benign_cropmarks | 8 | 0.00 |
| benign_footer | 13 | 0.00 |
| benign_plain | 40 | 0.00 |
| benign_watermark | 9 | 0.00 |
| covered | 10 | 1.00 |
| metadata | 10 | 1.00 |
| near_white | 10 | 1.00 |
| off_page | 10 | 1.00 |
| render_mode3 | 10 | 1.00 |
| tiny_font | 10 | 1.00 |
| white_on_white | 10 | 1.00 |
| zero_width | 10 | 1.00 |

Text classifier (unseen phrasings): {"heldout_unseen_phrasing_auc": 0.9402, "accuracy": 0.9159, "n_test": 321}
## Baseline comparison (same data)
| method | precision | recall | F1 | FPR |
|---|---|---|---|---|
| baseline (raw text + injection detector) | 1.000 | 0.675 | 0.806 | 0.000 |
| ours (render-vs-read gap) | 1.000 | 1.000 | 1.000 | 0.000 |

## Adversarial / red-team (latest)
- eval_adversarial.py (4 seeds each): light-gray 0.90 / 0.80, 3pt black, rotated white, text under 97%-gray box -> all flagged 4/4; benign white-on-dark header and gray table row -> 0/4 flagged.
- redteam.py (contrast 1.6/2.5, fragmented, homoglyph, unseen paraphrase, split-across-pages; 4 seeds): 0/24 evaded.
- Bugs found by this evaluation and fixed: (1) short metadata strings scored by text classifier -> false positives; (2) rotated text split per-letter by the extractor -> attack missed.
- Advanced detectors verified by tests: homoglyph, overlapping text, image-embedded hidden text (deep), incremental updates, DOCX, HTML, async jobs, tenants, feedback, MCP server, SARIF, RAG loader (27 tests).
- Caveat: all attacks are self-generated; saturated synthetic metrics are not real-world accuracy. Run `make real-eval DIR=...` on real PDFs.
