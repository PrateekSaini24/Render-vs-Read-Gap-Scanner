"""python cli.py <file|dir> [--sarif out.sarif] [--csv out.csv] [--json] [--clean out.txt]   exit 2 if any MALICIOUS (CI gate / ingestion gate)."""
import sys, os, json, csv, glob
from formats import scan_any, kind
from scanner import explain
a = sys.argv[1:]; tgt = a[0]; opt = lambda k: a[a.index(k) + 1] if k in a else None
files = sorted([p for p in glob.glob(os.path.join(tgt, "**", "*"), recursive=True) if p.lower().endswith((".pdf", ".docx", ".html", ".htm"))]) if os.path.isdir(tgt) else [tgt]; rows, bad, sar = [], False, []
for f in files:
    try: r = scan_any(open(f, "rb").read(), highlights=False)
    except Exception as e: rows.append(dict(file=f, verdict="ERROR", risk_score="", techniques=str(e))); continue
    t = sorted({x["technique"] for x in r["findings"]}); bad |= r["verdict"] == "MALICIOUS"
    sar += [dict(ruleId=x["technique"], level="error" if x["severity"] == "high" else "warning", message=dict(text=x["text"][:200]), locations=[dict(physicalLocation=dict(artifactLocation=dict(uri=f)))]) for x in r["findings"] if x["severity"] != "low"]
    rows.append(dict(file=f, verdict=r["verdict"], risk_score=r["risk_score"], techniques=";".join(t)))
    if opt("--clean") and len(files) == 1: open(opt("--clean"), "w").write(r["clean_text"])
    if "--json" in a: print(json.dumps({k: v for k, v in r.items() if k not in ("previews", "clean_text")}, indent=1))
    else: print(f"{r['verdict']:10} {r['risk_score']:3}  {f}  {t}")
if opt("--csv"): w = csv.DictWriter(open(opt("--csv"), "w", newline=""), fieldnames=["file", "verdict", "risk_score", "techniques"]); w.writeheader(); w.writerows(rows)
if opt("--sarif"): json.dump(dict(version="2.1.0", runs=[dict(tool=dict(driver=dict(name="gap-scanner")), results=sar)]), open(opt("--sarif"), "w"))
sys.exit(2 if bad else 0)
