"""Our scanner vs naive baseline (plain text-layer extraction + injection detector, i.e. what a normal RAG pipeline would do). Uses out-of-fold preds from train.py."""
import csv, json, collections, pdfplumber
from scanner import injection_score
rows = list(csv.DictReader(open("data/labels.csv"))); oof = json.load(open("data/oof.json")); res = collections.defaultdict(lambda: [0, 0, 0, 0])
for r in rows:
    raw = " ".join((p.extract_text() or "") for p in pdfplumber.open(r["path"]).pages)
    meta = " ".join(str(v) for v in (pdfplumber.open(r["path"]).metadata or {}).values())
    base = injection_score(raw + " " + meta)[0] >= .5; ours = oof[r["path"]] >= .5; y = int(r["label"])
    for name, p in (("baseline (raw text + injection detector)", base), ("ours (render-vs-read gap)", ours)):
        a = res[name]; a[0] += p and y; a[1] += (not p) and y; a[2] += p and not y; a[3] += (not p) and not y
L = ["", "## Baseline comparison (same data)", "| method | precision | recall | F1 | FPR |", "|---|---|---|---|---|"]
for n, (tp, fn, fp, tn) in res.items():
    p = tp / max(tp + fp, 1); rc = tp / max(tp + fn, 1); L.append(f"| {n} | {p:.3f} | {rc:.3f} | {2*p*rc/max(p+rc,1e-9):.3f} | {fp/max(fp+tn,1):.3f} |")
print("\n".join(L)); open("report.md", "a").write("\n".join(L) + "\n")
