# Render-vs-Read Gap Scanner  (document ingestion firewall for LLM/RAG)
Detects text that **machines read but humans don't see** in PDF / DOCX / HTML (hidden prompt injection in resumes, invoices, contracts) and returns a calibrated risk score, highlighted evidence and **sanitized text** safe for ingestion.

## Windows
1. Python 3.10+ (python.org, "Add to PATH" tick). 2. Tesseract: UB-Mannheim installer (default path auto-detected, else `set TESSERACT_CMD=...\tesseract.exe`). 3. Poppler: unzip (oschwartz10612/poppler-windows) and `set POPPLER_PATH=C:\poppler\Library\bin`.
4. `python -m venv venv && venv\Scripts\activate && pip install -r requirements.txt && set PYTHONUTF8=1 && python text_clf.py && python app.py`  (no `make`: run the python commands directly)

## Quick start
    sudo apt install tesseract-ocr poppler-utils      # mac: brew install tesseract poppler
    pip install -r requirements.txt
    python text_clf.py && python app.py               # UI http://localhost:5000  (PDF/DOCX/HTML, "deep" = image-hidden-text pass)
    python cli.py samples/ --csv out.csv --sarif out.sarif     # batch; exit code 2 if MALICIOUS
    make test                                          # pytest

## Detection coverage
| Layer | Techniques |
|---|---|
| PDF render-vs-read | white/low-contrast, tiny font, off-page, covered by shape, render mode 3, overlapping/glyph-mismatch text |
| PDF structure | metadata/annotation/form-value injection, embedded files, JavaScript, default-OFF layers, XFA, **incremental-update (deleted content recovery)** |
| Unicode | zero-width/tag chars, **homoglyph (Cyrillic/Greek) confusables** |
| Images (`deep`) | near-invisible text inside embedded images (contrast-amplified OCR diff) |
| DOCX / HTML | vanish/white/tiny runs, comments, metadata; display:none, off-screen, zero-font, opacity 0, white text, comments, alt/meta text |
| Text | regex + trained TF-IDF/LR classifier (+ optional DeBERTa via `INJ_MODEL`); document-level scoring catches payloads split across lines/pages |
| Scoring | calibrated GradientBoosting (11 features) + per-feature **explanation** (ablation) |

## Platform
- API: `/api/scan`, async `/api/jobs` (+poll), `/api/sanitize`, `/api/feedback` (allow/deny), `/api/drift` (PSI), `/api/audit`, `/api/stats`, `/metrics`, `/health`
- Multi-tenant keys + per-tenant thresholds: `GAP_KEYS='{"k1":{"tenant":"acme","suspicious":25,"malicious":60}}'` (or single `GAP_API_KEY`)
- Isolated scan subprocess + timeout, input guards, rate limit, security headers, audit log, Prometheus metrics (`monitoring/grafana_dashboard.json`)
- Docker (non-root, healthcheck), GitHub Actions CI, GitHub Action `.github/actions/gap-scan` (SARIF -> code scanning)
- Integrations: `integrations/safe_loader.py` (RAG loader with quarantine), `mcp_server.py` (tool `safe_read_document` for AI agents)

## ML & evaluation workflow
    make data train        # dataset.py -> train.py: 5-fold CV, bootstrap CIs, model.pkl, report.md
    make redteam           # adaptive attacker; --harvest adds evaders to training
    make compare           # vs naive text-layer baseline (appends to report.md)
    make eval-adv          # evasion + tricky-benign robustness
    make real-eval DIR=/path/to/your/clean/pdfs     # FPR on real PDFs + recall after injecting attacks into them
    make retrain-feedback  # active learning from analyst feedback
`finetune_deberta.py` and `vlm_check.py` are provided but **untested in the build sandbox** (need torch/API).

## Honest limits
Training data is synthetic; CV numbers saturate and are not real-world accuracy - run `real_eval.py` on real PDFs. Not built: browser extension, email gateway, billing, Postgres/Celery (SQLite + thread pool used), VLM-based image injection reading (hook only), glyph-remap fonts beyond the overlap/mismatch check.
Docs: `docs/ARCHITECTURE.md`, `docs/WRITEUP.md`, `docs/BENCHMARK_CARD.md`.
