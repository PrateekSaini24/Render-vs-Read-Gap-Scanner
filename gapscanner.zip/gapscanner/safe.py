"""Run scan in an isolated child process with a hard timeout (malicious PDFs can hang parsers/OCR)."""
import multiprocessing as mp, queue, os
from formats import scan_any as scan
def _w(q, data, kw):
    try: q.put(("ok", scan(data, **kw)))
    except Exception as e: q.put(("err", f"{type(e).__name__}: {e}"))
def scan_safe(data, timeout=90, **kw):
    ctx = mp.get_context("fork" if hasattr(os, "fork") else "spawn"); q = ctx.Queue(1); p = ctx.Process(target=_w, args=(q, data, kw), daemon=True); p.start()
    try: st, res = q.get(timeout=timeout)
    except queue.Empty:
        p.kill(); raise TimeoutError(f"scan {timeout}s se zyada laga, abort")
    finally: p.join(1)
    if st == "err": raise ValueError(res)
    return res
