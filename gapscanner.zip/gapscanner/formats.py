"""Same render-vs-read idea for DOCX and HTML (hidden runs / CSS-hidden text) + dispatcher."""
import re, io, zipfile, hashlib, math
from html.parser import HTMLParser
from xml.sax.saxutils import unescape
import scanner
def kind(b):
    h = b[:2048].lstrip()
    if h.startswith(b"%PDF"): return "pdf"
    if h[:2] == b"PK" and zipfile.is_zipfile(io.BytesIO(b)): return "docx"
    if re.search(rb"<(!doctype html|html|body|div|p|span)\b", h, re.I): return "html"
def _result(b, runs, visible, extra=()):
    f = []
    for tech, text in runs:
        s, m = scanner.injection_score(text); f.append(dict(page=1, technique=tech, text=text[:500], bbox=None, injection=s, matches=m, severity="high" if s > .6 else "medium"))
    for tech, text in extra:
        s, m = scanner.injection_score(text); f.append(dict(page=0, technique=tech, text=text[:500], bbox=None, injection=s, matches=m, severity="high" if s > .6 else "medium"))
    chars = sum(len(t) for _, t in runs); inj = max([x["injection"] for x in f] + [0]); techs = len({x["technique"] for x in f})
    z = -4 + 4.5 * inj + 2.5 * min(chars / 150, 1) + .8 * min(techs, 4); score = round(100 / (1 + math.exp(-z)))
    nv = len(" ".join(visible).split()); nh = len(" ".join(t for _, t in runs).split())
    return dict(sha256=hashlib.sha256(b).hexdigest(), pages=1, risk_score=score, verdict="MALICIOUS" if score >= 70 else "SUSPICIOUS" if score >= 30 else "CLEAN",
        features=dict(hidden_token_ratio=round(nh / max(nv + nh, 1), 4), hidden_chars=chars, n_techniques=techs, injection_score=round(inj, 3)), findings=f, clean_text="\n".join(visible), previews=[], explain=[])
def scan_docx(b):
    z = zipfile.ZipFile(io.BytesIO(b)); xml = z.read("word/document.xml").decode("utf8", "ignore"); runs, vis = [], []
    for m in re.finditer(r"<w:r[ >].*?</w:r>", xml, re.S):
        r = m.group(0); t = unescape("".join(re.findall(r"<w:t[^>]*>(.*?)</w:t>", r, re.S))).strip()
        if not t: continue
        tech = None
        if "<w:vanish" in r: tech = "docx_vanish"
        elif re.search(r'<w:color w:val="(FFFFFF|FEFEFE|FDFDFD)"', r, re.I): tech = "docx_white_text"
        elif (sz := re.search(r'<w:sz w:val="(\d+)"', r)) and int(sz.group(1)) < 8: tech = "docx_tiny_font"
        elif "<w:webHidden" in r: tech = "docx_web_hidden"
        (runs.append((tech, t)) if tech else vis.append(t))
    extra = [("docx_comment", re.sub("<[^>]+>", " ", z.read(n).decode("utf8", "ignore"))) for n in z.namelist() if n.endswith("comments.xml")]
    extra += [("docx_metadata", re.sub("<[^>]+>", " ", z.read(n).decode("utf8", "ignore"))) for n in z.namelist() if n == "docProps/core.xml"]
    return _result(b, runs, vis, [e for e in extra if e[1].strip()])
HID = [("css_display_none", r"display\s*:\s*none"), ("css_visibility_hidden", r"visibility\s*:\s*hidden"), ("css_zero_font", r"font-size\s*:\s*(0|[0-3])(px|pt|em|rem)?\s*(;|$)"),
       ("css_opacity_zero", r"opacity\s*:\s*0(\.0+)?\s*(;|$)"), ("css_offscreen", r"(left|top|text-indent)\s*:\s*-\d{3,}"), ("css_white_text", r"(^|;)\s*color\s*:\s*(#fff(fff)?|white|rgb\(\s*255\s*,\s*255\s*,\s*255\s*\))")]
class _P(HTMLParser):
    VOID = {"br", "img", "meta", "input", "hr", "link"}
    def __init__(s): super().__init__(); s.st, s.runs, s.vis, s.extra = [], [], [], []
    def handle_starttag(s, tag, a):
        a = dict(a); st = a.get("style", "") or ""
        tech = next((n for n, rx in HID if re.search(rx, st, re.I)), None) or ("html_hidden_attr" if "hidden" in a else "aria_hidden" if a.get("aria-hidden") == "true" else None)
        if tag == "img" and len(a.get("alt", "").split()) > 6: s.extra.append(("html_alt_text", a["alt"]))
        if tag == "meta" and len(a.get("content", "").split()) > 6: s.extra.append(("html_meta", a["content"]))
        if tag not in s.VOID: s.st.append((tag, tech))
    def handle_endtag(s, tag):
        for i in range(len(s.st) - 1, -1, -1):
            if s.st[i][0] == tag: del s.st[i:]; break
    def handle_data(s, d):
        if not d.strip() or any(t in ("script", "style") for t, _ in s.st): return
        tech = next((t for _, t in s.st if t), None); (s.runs.append((tech, d.strip())) if tech else s.vis.append(d.strip()))
    def handle_comment(s, d):
        if len(d.split()) > 3: s.extra.append(("html_comment", d))
def scan_html(b):
    p = _P(); p.feed(b.decode("utf8", "ignore")); return _result(b, p.runs, p.vis, p.extra)
def scan_any(b, **kw):
    k = kind(b)
    if k == "pdf": return scanner.scan(b, **kw)
    if k == "docx": return scan_docx(b)
    if k == "html": return scan_html(b)
    raise ValueError("unsupported file type (PDF/DOCX/HTML only)")
