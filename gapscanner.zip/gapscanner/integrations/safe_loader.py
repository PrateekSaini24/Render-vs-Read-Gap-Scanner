"""RAG ingestion firewall: scan before loading. Works standalone; returns langchain Document if langchain_core installed.
    docs = SafeLoader("cv.pdf", quarantine_dir="quarantine").load()   # [] + file moved to quarantine if MALICIOUS"""
import os, shutil, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from formats import scan_any
try: from langchain_core.documents import Document
except Exception:
    class Document:
        def __init__(self, page_content, metadata=None): self.page_content, self.metadata = page_content, metadata or {}
class BlockedDocument(Exception): pass
class SafeLoader:
    def __init__(self, path, quarantine_dir="quarantine", block=("MALICIOUS",), raise_on_block=False): self.path, self.q, self.block, self.raise_on_block = path, quarantine_dir, block, raise_on_block
    def load(self):
        r = scan_any(open(self.path, "rb").read(), highlights=False); meta = dict(source=self.path, verdict=r["verdict"], risk_score=r["risk_score"], sha256=r["sha256"], techniques=sorted({f["technique"] for f in r["findings"]}))
        if r["verdict"] in self.block:
            os.makedirs(self.q, exist_ok=True); shutil.copy(self.path, os.path.join(self.q, r["sha256"][:12] + "_" + os.path.basename(self.path)))
            if self.raise_on_block: raise BlockedDocument(meta)
            return []
        return [Document(page_content=r["clean_text"], metadata=meta)]   # sanitized text only
