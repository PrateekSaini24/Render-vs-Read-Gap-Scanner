import os, sys, io, json, tempfile, subprocess, pytest
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__)))); sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
os.environ["GAP_DB"] = tempfile.mktemp(suffix=".db")
import assets as A, formats, scanner
techs = lambda r: {f["technique"] for f in r["findings"]}
def test_homoglyph(): r = scanner.scan(A.homoglyph_pdf(), highlights=False); assert "homoglyph" in techs(r) and r["features"]["homoglyph_count"] >= 2
def test_overlap_mismatch(): r = scanner.scan(A.overlap_pdf(), highlights=False); assert techs(r) & {"glyph_or_overlap_mismatch", "covered_or_invisible"} and r["verdict"] == "MALICIOUS"
def test_incremental(): assert "incremental_update" in techs(scanner.scan(A.incremental_pdf(), highlights=False))
def test_image_hidden_text(): assert "image_hidden_text" in techs(scanner.scan(A.image_pdf(True), highlights=False, deep=True)) and "image_hidden_text" not in techs(scanner.scan(A.image_pdf(False), highlights=False, deep=True))
def test_docx(): r = formats.scan_docx(A.docx_bytes()); assert r["verdict"] == "MALICIOUS" and {"docx_vanish", "docx_white_text", "docx_tiny_font"} <= techs(r) and "Rahul" in r["clean_text"] and "Ignore" not in r["clean_text"]
def test_html(): assert formats.scan_html(A.html_bytes())["verdict"] == "MALICIOUS" and formats.scan_html(A.html_bytes(False))["verdict"] == "CLEAN"
def test_kind(): assert formats.kind(A.docx_bytes()) == "docx" and formats.kind(A.html_bytes()) == "html" and formats.kind(b"hello") is None
def test_loader_quarantine(tmp_path):
    from integrations.safe_loader import SafeLoader
    p = tmp_path / "bad.docx"; p.write_bytes(A.docx_bytes()); assert SafeLoader(str(p), str(tmp_path / "q")).load() == [] and len(os.listdir(tmp_path / "q")) == 1
    h = tmp_path / "ok.html"; h.write_bytes(A.html_bytes(False)); d = SafeLoader(str(h), str(tmp_path / "q")).load(); assert d and "Python" in d[0].page_content
def test_mcp(tmp_path):
    p = tmp_path / "bad.docx"; p.write_bytes(A.docx_bytes()); root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    msgs = [dict(jsonrpc="2.0", id=1, method="initialize"), dict(jsonrpc="2.0", id=2, method="tools/list"), dict(jsonrpc="2.0", id=3, method="tools/call", params=dict(name="safe_read_document", arguments=dict(path=str(p))))]
    out = subprocess.run([sys.executable, "mcp_server.py"], input="\n".join(map(json.dumps, msgs)), capture_output=True, text=True, cwd=root).stdout.splitlines()
    assert "safe_read_document" in out[1] and "BLOCKED" in out[2]
def test_cli_sarif(tmp_path):
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); (tmp_path / "a.docx").write_bytes(A.docx_bytes())
    r = subprocess.run([sys.executable, "cli.py", str(tmp_path), "--sarif", str(tmp_path / "o.sarif")], cwd=root, capture_output=True); assert r.returncode == 2 and json.load(open(tmp_path / "o.sarif"))["runs"][0]["results"]
def test_jobs_feedback_tenants_drift():
    import time, app as P
    c = P.app.test_client(); up = lambda h={}: c.post("/api/jobs", data={"file": (io.BytesIO(A.docx_bytes()), "a.docx")}, content_type="multipart/form-data", headers=h)
    r = up(); assert r.status_code == 202; jid = r.get_json()["job_id"]
    for _ in range(60):
        j = c.get(f"/api/jobs/{jid}").get_json()
        if j["status"] != "queued": break
        time.sleep(.5)
    assert j["status"] == "done" and j["result"]["verdict"] == "MALICIOUS"; sha = j["result"]["sha256"]
    assert c.post("/api/feedback", json=dict(sha256=sha, label="deny")).get_json()["ok"] and c.post("/api/feedback", json=dict(sha256=sha, label="x")).status_code == 400
    P.KEYS = {"k1": dict(tenant="acme", malicious=101, suspicious=101)}
    assert up().status_code == 401
    r = c.post("/api/scan", data={"file": (io.BytesIO(A.docx_bytes()), "a.docx")}, content_type="multipart/form-data", headers={"X-API-Key": "k1"}).get_json(); assert r["verdict"] == "CLEAN"  # tenant policy overrides
    assert len(c.get("/api/audit", headers={"X-API-Key": "k1"}).get_json()) >= 1; P.KEYS = {}
    assert c.get("/api/drift").get_json()["status"] == "insufficient_data"
def test_rotated_white_regression():
    import io, random
    from reportlab.pdfgen import canvas
    from reportlab.lib.pagesizes import A4
    import dataset
    random.seed(0); b = io.BytesIO(); c = canvas.Canvas(b, pagesize=A4); dataset.body(c, "resume"); c.saveState(); c.translate(500, 300); c.rotate(90); c.setFillColorRGB(1, 1, 1)
    c.setFont("Helvetica", 10); c.drawString(0, 0, A.INJ); c.restoreState(); c.save()
    r = scanner.scan(b.getvalue(), highlights=False); assert r["verdict"] != "CLEAN" and any("Ignore" in f["text"] for f in r["findings"])
