# Architecture & Threat Model
## Problem
LLM/RAG ingestion reads a PDF's **text layer**; humans see the **rendered page**. Any gap is an attack surface (indirect prompt injection in resumes, invoices, contracts).
## Pipeline
```mermaid
flowchart LR
A[Upload PDF] --> G[Guard: size/page/pixel limits]
G --> S[Isolated subprocess + timeout]
S --> T[Text layer: pdfplumber word,bbox,size,colour]
S --> R[Render 200 DPI: pdf2image] --> O[OCR: Tesseract]
S --> X[Structure: pikepdf - metadata, annots, JS, embedded, OCG, Tr 3]
T --> D[Position-aware diff]
O --> D
D --> F[Findings per technique + bbox]
X --> F
F --> I[Injection scoring: regex + trained TF-IDF/LR text classifier]
I --> M[Calibrated GradientBoosting risk model 0-100]
M --> Out[Verdict + highlighted pages + sanitized text]
```
## Design decisions
- **Detection is deterministic** (render vs read diff); ML only scores risk, to keep false positives low (legit footers, watermarks, crop marks).
- **Contrast uses the rendered background** (median pixel under the bbox), so white text on a dark header is *not* flagged.
- **Isolation**: each scan runs in a child process killed on timeout; guards reject oversized pages; filenames sanitised; CSP/nosniff headers; optional API key + rate limit.
- **Dedupe by SHA-256**; findings stored for threshold tuning and technique stats; `/metrics` for Prometheus.
- **Sanitizer output** (`/api/sanitize`) returns only OCR-consistent visible text for safe ingestion.
## Threat model
| In scope | Out of scope / known gaps |
|---|---|
| white/low-contrast, tiny, off-page, occluded, Tr 3, metadata/annotation injection, zero-width/tag chars | text rendered *inside images* that a VLM reads; adaptive attackers who make hidden text OCR-visible but human-imperceptible; encrypted PDFs; Form XObject-only text edge cases |
## Evaluation methodology
Synthetic labelled dataset (clean, benign-hidden, 8 attack techniques) -> 5-fold CV out-of-fold metrics with bootstrap CIs (`report.md`); text classifier measured on **unseen phrasings**; `eval_adversarial.py` tests evasions and tricky benign designs. Limitation: synthetic data - retrain on real corpora before production.
## Roadmap
VLM-based image-injection check, Postgres + job queue (Celery/RQ) for scale, active-learning loop from allow/deny history, per-tenant thresholds.

## v2 additions
Formats: `formats.py` (DOCX/HTML) + dispatcher. Image pass: `imgscan.py` (contrast-amplified OCR diff). Platform: async jobs, per-tenant policy, feedback -> `retrain_feedback.py`, PSI drift, audit log, SARIF, MCP server, RAG loader. Evaluation: CV+CIs, baseline comparison, red-team, real-data eval.
