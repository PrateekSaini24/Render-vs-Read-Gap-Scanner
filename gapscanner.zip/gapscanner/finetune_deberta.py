"""UNTESTED in the build sandbox (needs torch+transformers+GPU/CPU time). Fine-tune a DeBERTa prompt-injection detector on text_clf's generated data (+ add your own).
python finetune_deberta.py  -> ./deberta-inj ; then: INJ_MODEL=./deberta-inj python app.py  (ensembled with regex+TF-IDF via max())"""
import torch, text_clf
from transformers import AutoTokenizer, AutoModelForSequenceClassification, Trainer, TrainingArguments
name = "microsoft/deberta-v3-small"; tok = AutoTokenizer.from_pretrained(name); (Xa, ya), (Xt, yt) = text_clf.data(False), text_clf.data(True)
class DS(torch.utils.data.Dataset):
    def __init__(s, X, y): s.e, s.y = tok(X, truncation=True, padding=True, max_length=128), y
    def __len__(s): return len(s.y)
    def __getitem__(s, i): return {**{k: torch.tensor(v[i]) for k, v in s.e.items()}, "labels": torch.tensor(s.y[i])}
m = AutoModelForSequenceClassification.from_pretrained(name, num_labels=2)
Trainer(model=m, args=TrainingArguments("deberta-inj", num_train_epochs=3, per_device_train_batch_size=16, report_to=[]), train_dataset=DS(Xa, ya), eval_dataset=DS(Xt, yt)).train()
m.save_pretrained("deberta-inj"); tok.save_pretrained("deberta-inj")
