"""Minimal MCP server (stdio JSON-RPC, no deps): tool `safe_read_document(path)` -> verdict + sanitized text. Agents use this instead of raw PDF readers.
Claude Desktop config: {"mcpServers":{"gap":{"command":"python","args":["/path/mcp_server.py"]}}}"""
import sys, json
from formats import scan_any
TOOL = dict(name="safe_read_document", description="Scan a PDF/DOCX/HTML for hidden prompt-injection and return sanitized visible text. Refuses MALICIOUS files.",
            inputSchema=dict(type="object", properties=dict(path=dict(type="string")), required=["path"]))
def call(args):
    r = scan_any(open(args["path"], "rb").read(), highlights=False); head = f"verdict={r['verdict']} risk={r['risk_score']} techniques={sorted({f['technique'] for f in r['findings']})}"
    return head + ("\nBLOCKED: hidden injection detected; content withheld." if r["verdict"] == "MALICIOUS" else "\n\n" + r["clean_text"])
for line in sys.stdin:
    try: m = json.loads(line)
    except Exception: continue
    i, meth = m.get("id"), m.get("method"); res = None
    if meth == "initialize": res = dict(protocolVersion="2024-11-05", capabilities=dict(tools={}), serverInfo=dict(name="gap-scanner", version="1.0"))
    elif meth == "tools/list": res = dict(tools=[TOOL])
    elif meth == "tools/call":
        try: res = dict(content=[dict(type="text", text=call(m["params"]["arguments"]))])
        except Exception as e: res = dict(content=[dict(type="text", text=f"error: {e}")], isError=True)
    elif i is None: continue
    else: print(json.dumps(dict(jsonrpc="2.0", id=i, error=dict(code=-32601, message="method not found"))), flush=True); continue
    print(json.dumps(dict(jsonrpc="2.0", id=i, result=res)), flush=True)
